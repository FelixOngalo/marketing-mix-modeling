# Functions for the marketing-mix-modelling project: a simulator with KNOWN channel
# effects, cleaning, adstock/saturation model fitting, ROI and budget optimisation.

library(dplyr)
library(tibble)

CHANNELS <- c("tv", "search", "social", "display")

# ---- Ground truth (used to generate the data and to grade the analysis) ---
TRUE_PARAMS <- tibble(
  channel = CHANNELS,
  beta  = c(220, 110, 70, 40),         # weekly sales ($k) at full saturation
  decay = c(0.70, 0.15, 0.45, 0.30),   # share of last week's adstock carried over
  K     = c(150, 40, 30, 20),          # adstock level giving half of the maximum effect
  shape = c(1.0, 1.0, 1.0, 1.0))       # Hill shape; the fitted model also assumes shape = 1

adstock <- function(x, decay) as.numeric(stats::filter(x, decay, method = "recursive"))   # a_t = x_t + decay * a_{t-1}
hill <- function(x, K, shape = 1) x^shape / (x^shape + K^shape)

#' Steady-state weekly effect of spending `s` ($k per week) every week on one channel.
steady_effect <- function(s, beta, decay, K, shape = 1) beta * hill(s / (1 - decay), K, shape)

#' Simulate three years of weekly sales. Channel spend patterns create the usual analytics traps:
#' TV runs in flights, search spend follows seasonal demand (endogenous), social is flighted and often
#' coincides with TV (collinear), display runs in heavy bursts and is over-spent (saturated).
simulate_mmm <- function(n_weeks = 156, seed = 1, messy = TRUE) {
  set.seed(seed)
  t <- seq_len(n_weeks)
  season <- 50 * sin(2 * pi * t / 52) + 20 * cos(2 * pi * t / 52) + 15 * sin(4 * pi * t / 52)
  promo <- rbinom(n_weeks, 1, 0.15)
  price_index <- 100 + as.numeric(arima.sim(list(ar = 0.5), n_weeks, sd = 1.5)) - 6 * promo

  tv_on <- integer(0)
  while (length(tv_on) < n_weeks) tv_on <- c(tv_on, rep(1, sample(3:6, 1)), rep(0, sample(2:5, 1)))
  tv_on <- tv_on[seq_len(n_weeks)]
  tv <- tv_on * pmax(rnorm(n_weeks, 95, 15), 0)
  search <- pmax(25 * (1 + 0.5 * season / max(abs(season))) * exp(rnorm(n_weeks, 0, 0.40)), 0)
  flights <- function(a, b, c, d) {
    o <- integer(0)
    while (length(o) < n_weeks) o <- c(o, rep(1, sample(a:(b - 1), 1)), rep(0, sample(c:(d - 1), 1)))
    o[seq_len(n_weeks)]
  }
  social_on <- ifelse(runif(n_weeks) < 0.35, tv_on, flights(2, 5, 2, 5))      # 35% of weeks follow TV
  social <- social_on * 22 * exp(rnorm(n_weeks, 0, 0.3))
  display <- flights(2, 6, 2, 6) * 60 * exp(rnorm(n_weeks, 0, 0.3))
  spend <- cbind(tv = tv, search = search, social = social, display = display)

  contrib <- sapply(CHANNELS, function(ch) {
    p <- TRUE_PARAMS[TRUE_PARAMS$channel == ch, ]
    p$beta * hill(adstock(spend[, ch], p$decay), p$K, p$shape)
  })
  baseline <- 400 + 0.4 * t
  price_effect <- -5 * (price_index - 100)
  promo_effect <- 20 * promo
  sales <- baseline + season + price_effect + promo_effect + rowSums(contrib) + rnorm(n_weeks, 0, 12)

  raw <- tibble(week_start = as.Date("2022-01-03") + 7 * (t - 1), sales = round(sales, 2),
                tv_spend = round(tv, 2), search_spend = round(search, 2), social_spend = round(social, 2),
                display_spend = round(display, 2), price_index = round(price_index, 2),
                promo = ifelse(promo == 1, "Y", "N"))
  truth <- bind_cols(tibble(week_start = raw$week_start, baseline = baseline, season = season,
                            price_effect = price_effect, promo_effect = promo_effect),
                     as_tibble(contrib) |> rename_with(~ paste0("contrib_", .x)))

  if (messy) {
    raw$tv_spend[sample(n_weeks, 2)] <- NA; raw$search_spend[sample(n_weeks, 1)] <- NA     # tracking outages
    raw <- bind_rows(raw, raw[sample(n_weeks, 1), ]) |> arrange(week_start)                 # a duplicated week
  }
  list(raw = raw, truth = truth, spend_true = spend)
}

#' Clean and build features. Missing spend is filled by linear interpolation between neighbouring weeks.
clean_mmm <- function(raw) {
  n0 <- nrow(raw)
  x <- distinct(raw) |> arrange(week_start)
  n_dup <- n0 - nrow(x)
  gaps <- sum(diff(x$week_start) != 7)
  spend_cols <- paste0(CHANNELS, "_spend")
  n_na <- sum(is.na(x[spend_cols]))
  for (cl in spend_cols) {
    idx <- seq_len(nrow(x)); ok <- !is.na(x[[cl]])
    x[[cl]] <- approx(idx[ok], x[[cl]][ok], xout = idx, rule = 2)$y
  }
  x <- x |> mutate(promo = as.integer(toupper(trimws(promo)) %in% c("Y", "YES", "1")), t = row_number(),
                   sin1 = sin(2 * pi * t / 52), cos1 = cos(2 * pi * t / 52), sin2 = sin(4 * pi * t / 52), cos2 = cos(4 * pi * t / 52))
  log <- tibble(step = c("Rows received", "Duplicate weeks removed", "Missing weeks (gaps in the calendar)",
                         "Missing spend values interpolated", "Weeks analysed"),
                rows = c(n0, n_dup, gaps, n_na, nrow(x)))
  list(data = x, log = log)
}

CONTROLS <- c("t", "sin1", "cos1", "sin2", "cos2", "price_index", "promo")

# ---- The model --------------------------------------------------------
# sales_t = controls_t' gamma + sum_c beta_c * x_ct / (x_ct + K_c) + e_t, where x_ct is the geometric
# adstock of channel c's spend with decay theta_c. For given (theta, K) the model is linear in
# (gamma, beta), so those are solved by least squares and only (theta, K) are searched numerically
# ("variable projection"). Negative channel coefficients are not allowed: such a channel is dropped.

channel_features <- function(spend, decay, K) {
  sapply(seq_along(CHANNELS), function(j) hill(adstock(spend[, j], decay[j]), K[j], 1))
}

fit_given <- function(y, controls, spend, decay, K) {
  Z <- channel_features(spend, decay, K)
  keep <- seq_along(CHANNELS)
  repeat {
    fit <- lm.fit(cbind(controls, Z[, keep, drop = FALSE]), y)
    nc <- ncol(controls); b <- fit$coefficients[nc + seq_along(keep)]
    if (all(b >= 0) || length(keep) == 0) break
    keep <- keep[-which.min(b)]
  }
  beta <- rep(0, length(CHANNELS)); beta[keep] <- b
  list(rss = sum(fit$residuals^2), gamma = fit$coefficients[seq_len(nc)], beta = beta, Z = Z, fitted = y - fit$residuals)
}

#' Fit the model by multi-start L-BFGS-B on the concentrated least-squares problem.
fit_mmm <- function(d, n_starts = 8, seed = 1, start = NULL) {
  set.seed(seed)
  y <- d$sales; controls <- cbind(Intercept = 1, as.matrix(d[CONTROLS]))
  spend <- as.matrix(d[paste0(CHANNELS, "_spend")]); colnames(spend) <- CHANNELS
  nC <- length(CHANNELS)
  ref <- 2 * colMeans(spend)                                     # a typical steady-state adstock level per channel
  lower <- c(rep(0, nC), 0.25 * ref); upper <- c(rep(0.9, nC), 4 * ref)
  obj <- function(par) fit_given(y, controls, spend, par[1:nC], par[nC + 1:nC])$rss
  starts <- if (is.null(start)) {
    lapply(seq_len(n_starts), function(i) c(runif(nC, 0.05, 0.85), exp(runif(nC, log(0.2 * ref), log(4 * ref)))))
  } else list(start)
  best <- NULL
  for (s in starts) {
    r <- optim(s, obj, method = "L-BFGS-B", lower = lower, upper = upper)
    if (is.null(best) || r$value < best$value) best <- r
  }
  decay <- best$par[1:nC]; K <- best$par[nC + 1:nC]
  g <- fit_given(y, controls, spend, decay, K)
  list(decay = setNames(decay, CHANNELS), K = setNames(K, CHANNELS), beta = setNames(g$beta, CHANNELS), gamma = g$gamma,
       rss = g$rss, fitted = g$fitted, n = length(y), start = best$par)
}

#' Predict sales for rows of `d` (spend history must be included so adstock carries over).
predict_mmm <- function(fit, d) {
  controls <- cbind(Intercept = 1, as.matrix(d[CONTROLS]))
  spend <- as.matrix(d[paste0(CHANNELS, "_spend")])
  Z <- channel_features(spend, fit$decay, fit$K)
  as.numeric(controls %*% fit$gamma + Z %*% fit$beta)
}

#' Weekly contribution of each channel and of the non-media baseline.
decompose_mmm <- function(fit, d) {
  spend <- as.matrix(d[paste0(CHANNELS, "_spend")])
  Z <- channel_features(spend, fit$decay, fit$K)
  contrib <- sweep(Z, 2, fit$beta, "*"); colnames(contrib) <- paste0("contrib_", CHANNELS)
  controls <- cbind(Intercept = 1, as.matrix(d[CONTROLS]))
  as_tibble(contrib) |> mutate(non_media = as.numeric(controls %*% fit$gamma), week_start = d$week_start, .before = 1)
}

# ---- ROI and budget optimisation -----------------------------------------

#' Average ROI = incremental sales / spend; marginal ROI = derivative of the steady-state effect
#' with respect to weekly spend, evaluated at the average weekly spend `s0`.
marginal_roi <- function(s0, beta, decay, K) beta * K / ((s0 / (1 - decay) + K)^2 * (1 - decay))

#' Closed-form optimum for Hill shape 1: maximise sum_c beta_c x_c/(x_c + K_c), x_c = s_c/(1 - decay_c),
#' subject to sum s_c = total and lo <= s <= hi. At the optimum the marginal returns of all unconstrained
#' channels are equal (to lambda), which gives s_c(lambda) in closed form; lambda is found by bisection so
#' that the budget is spent exactly.
waterfill <- function(beta, decay, K, total, lo, hi) {
  s_of <- function(lam) pmin(pmax((1 - decay) * (sqrt(pmax(beta, 1e-12) * K / ((1 - decay) * lam)) - K), lo), hi)
  f <- function(loglam) sum(s_of(exp(loglam))) - total
  stopifnot(sum(lo) <= total + 1e-9, sum(hi) >= total - 1e-9)
  r <- uniroot(f, c(-40, 20), tol = 1e-12)
  s_of(exp(r$root))
}

#' General numeric optimiser for any response functions (used for the TRUE response curves):
#' maximise total(s) over the budget simplex with bounds, by multi-start Nelder-Mead on a penalised objective.
optimise_numeric <- function(total_fun, total, lo, hi, n_starts = 12, seed = 1) {
  set.seed(seed); nC <- length(lo)
  to_s <- function(u) c(u, total - sum(u))
  obj <- function(u) { s <- to_s(u); pen <- sum(pmax(lo - s, 0)^2 + pmax(s - hi, 0)^2); -total_fun(s) + 1e4 * pen }
  best <- NULL
  for (i in seq_len(n_starts)) {
    u0 <- runif(nC - 1, lo[-nC], hi[-nC])
    r <- optim(u0, obj, method = "Nelder-Mead", control = list(maxit = 4000, reltol = 1e-12))
    if (is.null(best) || r$value < best$value) best <- r
  }
  s <- to_s(best$par); pmin(pmax(s, lo), hi)
}
