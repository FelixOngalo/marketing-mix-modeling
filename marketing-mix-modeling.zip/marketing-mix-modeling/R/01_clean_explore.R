source("R/mmm_functions.R")
library(readr)
library(tidyr)

raw <- read_csv("data/raw/weekly_marketing.csv", show_col_types = FALSE)
cleaned <- clean_mmm(raw)
print(cleaned$log)
d <- cleaned$data
stopifnot(nrow(d) == 156, !anyNA(d[paste0(CHANNELS, "_spend")]), all(diff(d$week_start) == 7))

# ---- Descriptives ----------------------------------------------------------
spend_cols <- paste0(CHANNELS, "_spend")
spend_summary <- tibble(channel = CHANNELS, mean_weekly_spend = colMeans(d[spend_cols]), total_spend = colSums(d[spend_cols]),
                        share_of_budget = colSums(d[spend_cols]) / sum(d[spend_cols]),
                        weeks_with_zero_spend = colSums(d[spend_cols] == 0))
print(spend_summary)
cat("Average weekly sales ($k):", round(mean(d$sales), 1), "\n")

# ---- Why attribution is hard: the spend series move together --------------------
cor_spend <- cor(d[spend_cols]); colnames(cor_spend) <- rownames(cor_spend) <- CHANNELS
print(round(cor_spend, 2))
vif <- sapply(spend_cols, function(v) 1 / (1 - summary(lm(reformulate(setdiff(c(spend_cols, CONTROLS), v), v), data = d))$r.squared))
vif <- tibble(variable = spend_cols, vif = unname(vif))
print(vif)

# Search spend follows seasonal demand
seas_cor <- tibble(variable = c("search_spend", "tv_spend", "social_spend", "display_spend"),
                   correlation_with_sales = c(cor(d$search_spend, d$sales), cor(d$tv_spend, d$sales), cor(d$social_spend, d$sales), cor(d$display_spend, d$sales)))
print(seas_cor)

saveRDS(list(data = d, log = cleaned$log, spend_summary = spend_summary, cor_spend = cor_spend, vif = vif, seas_cor = seas_cor),
        "data/clean/mmm_clean.rds")
