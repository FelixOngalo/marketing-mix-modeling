source("R/mmm_functions.R")
library(tidyr)
set.seed(2)

obj <- readRDS("data/clean/mmm_clean.rds"); d <- obj$data
truth <- readRDS("data/clean/truth_contributions.rds")
spend_cols <- paste0(CHANNELS, "_spend")
n <- nrow(d); n_test <- 26; train <- d[seq_len(n - n_test), ]; test_idx <- (n - n_test + 1):n
mape <- function(y, p) mean(abs(y - p) / y)

# ---- 1. Models: a naive regression and the marketing-mix model ------------------
naive_lin_formula <- reformulate(c(CONTROLS, spend_cols), "sales")
naive_nocontrols  <- reformulate(spend_cols, "sales")
m_lin  <- lm(naive_lin_formula, data = train)         # linear in raw spend, with controls
m_bare <- lm(naive_nocontrols, data = train)          # linear in raw spend, no controls
fit_train <- fit_mmm(train, n_starts = 8, seed = 1)   # adstock + saturation, with controls
fit_full  <- fit_mmm(d, n_starts = 8, seed = 1)

holdout <- tibble(model = c("Linear, no controls", "Linear with controls", "Adstock + saturation (MMM)"),
                  train_rmse = c(sqrt(mean(resid(m_bare)^2)), sqrt(mean(resid(m_lin)^2)), sqrt(fit_train$rss / nrow(train))),
                  test_mape = c(mape(d$sales[test_idx], predict(m_bare, d[test_idx, ])), mape(d$sales[test_idx], predict(m_lin, d[test_idx, ])),
                                mape(d$sales[test_idx], predict_mmm(fit_train, d)[test_idx])))
print(holdout)

# ---- 2. Estimated parameters versus the truth (full-sample fit) --------------
params <- tibble(channel = CHANNELS, decay_est = unname(fit_full$decay), decay_true = TRUE_PARAMS$decay,
                 K_est = unname(fit_full$K), K_true = TRUE_PARAMS$K, beta_est = unname(fit_full$beta), beta_true = TRUE_PARAMS$beta)
print(params)

# ---- 3. Contributions and ROI -----------------------------------------------
dec <- decompose_mmm(fit_full, d)
spend_tot <- colSums(d[spend_cols])
tr_contrib <- colSums(truth[paste0("contrib_", CHANNELS)])
est_contrib <- colSums(dec[paste0("contrib_", CHANNELS)])
roi <- tibble(channel = CHANNELS, total_spend = unname(spend_tot),
              contribution_true = unname(tr_contrib), contribution_mmm = unname(est_contrib),
              roi_true = unname(tr_contrib / spend_tot), roi_mmm = unname(est_contrib / spend_tot),
              roi_linear_with_controls = unname(coef(lm(naive_lin_formula, data = d))[spend_cols]),
              roi_linear_no_controls = unname(coef(lm(naive_nocontrols, data = d))[spend_cols]))
print(roi)

# Share of sales explained by media
share <- tibble(source = c("Media (all channels)", "Non-media"), true = c(sum(tr_contrib), sum(d$sales) - sum(tr_contrib)),
                mmm = c(sum(est_contrib), sum(d$sales) - sum(est_contrib))) |> mutate(across(c(true, mmm), ~ .x / sum(d$sales), .names = "{.col}_share"))
print(share)

# ---- 4. Marginal ROI at current spend (last 52 weeks average) ----------------
s0 <- colMeans(tail(d[spend_cols], 52)); names(s0) <- CHANNELS
true_marg <- sapply(CHANNELS, function(ch) { p <- TRUE_PARAMS[TRUE_PARAMS$channel == ch, ]; h <- 0.01
  (steady_effect(s0[[ch]] + h, p$beta, p$decay, p$K, p$shape) - steady_effect(s0[[ch]] - h, p$beta, p$decay, p$K, p$shape)) / (2 * h) })
marg <- tibble(channel = CHANNELS, weekly_spend = unname(s0), marginal_roi_mmm = marginal_roi(s0, fit_full$beta, fit_full$decay, fit_full$K),
               marginal_roi_true = unname(true_marg),
               average_roi_true_steady_state = sapply(CHANNELS, function(ch) { p <- TRUE_PARAMS[TRUE_PARAMS$channel == ch, ]; steady_effect(s0[[ch]], p$beta, p$decay, p$K, p$shape) / s0[[ch]] }))
print(marg)

# ---- 5. Residual diagnostics ----------------------------------------------
resid_df <- tibble(week_start = d$week_start, fitted = fit_full$fitted, residual = d$sales - fit_full$fitted)
acf1 <- cor(resid_df$residual[-1], resid_df$residual[-nrow(resid_df)])
cat("Lag-1 autocorrelation of MMM residuals:", round(acf1, 3), "\n")

# Fitted versus actual and the decomposition for plotting
pred_df <- tibble(week_start = d$week_start, actual = d$sales, mmm_fit = predict_mmm(fit_train, d),
                  set = ifelse(seq_len(n) %in% test_idx, "holdout", "training"))
decomp_long <- dec |> select(week_start, starts_with("contrib_"), non_media) |>
  pivot_longer(-week_start, names_to = "component", values_to = "sales")

saveRDS(list(holdout = holdout, params = params, roi = roi, share = share, marg = marg, acf1 = acf1, resid_df = resid_df,
             pred_df = pred_df, decomp_long = decomp_long, fit = fit_full, s0 = s0, n_test = n_test),
        "data/clean/mmm_results.rds")
