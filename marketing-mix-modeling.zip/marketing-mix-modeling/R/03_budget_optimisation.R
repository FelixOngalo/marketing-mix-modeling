source("R/mmm_functions.R")
library(tidyr)
set.seed(3)

d <- readRDS("data/clean/mmm_clean.rds")$data
res <- readRDS("data/clean/mmm_results.rds"); fit <- res$fit; s0 <- res$s0
spend_cols <- paste0(CHANNELS, "_spend")
TP <- TRUE_PARAMS

# ---- 1. Optimal allocation of the current budget -------------------------------
total <- sum(s0); lo <- 0.5 * s0; hi <- 1.5 * s0
s_wf <- waterfill(fit$beta, fit$decay, fit$K, total, lo, hi)
eff_est <- function(s) sum(steady_effect(s, fit$beta, fit$decay, fit$K, 1))
s_num <- optimise_numeric(eff_est, total, lo, hi)
cat("Water-filling and numeric optimiser agree (max abs difference in $k):", signif(max(abs(s_wf - s_num)), 3), "\n")

eff_true <- function(s) sum(mapply(function(ch, si) steady_effect(si, TP$beta[TP$channel == ch], TP$decay[TP$channel == ch], TP$K[TP$channel == ch], TP$shape[TP$channel == ch]), CHANNELS, s))
s_true_opt <- optimise_numeric(eff_true, total, lo, hi)
alloc <- tibble(channel = CHANNELS, current = unname(s0), mmm_recommended = s_wf, truly_best = s_true_opt) |>
  mutate(change_pct_recommended = 100 * (mmm_recommended / current - 1))
print(alloc)

# Value of the recommendation, judged by the TRUE response curves
value <- tibble(
  plan = c("Current allocation", "MMM-recommended allocation", "Truly best allocation"),
  predicted_by_mmm = c(eff_est(s0), eff_est(s_wf), eff_est(s_true_opt)),
  true_weekly_incremental_sales = c(eff_true(s0), eff_true(s_wf), eff_true(s_true_opt))) |>
  mutate(true_gain_vs_current = true_weekly_incremental_sales - true_weekly_incremental_sales[1],
         share_of_best_possible_gain = true_gain_vs_current / (true_weekly_incremental_sales[3] - true_weekly_incremental_sales[1]))
print(value)

# ---- 2. Response curves (steady-state weekly effect against weekly spend) ----------
grid <- seq(0, 2 * max(s0), length.out = 60)
curves <- bind_rows(lapply(seq_along(CHANNELS), function(j) {
  ch <- CHANNELS[j]; g <- seq(0, 2.5 * s0[[ch]], length.out = 60)
  tibble(channel = ch, spend = g,
         mmm = steady_effect(g, fit$beta[[j]], fit$decay[[j]], fit$K[[j]], 1),
         truth = steady_effect(g, TP$beta[j], TP$decay[j], TP$K[j], TP$shape[j]), current = s0[[ch]])
}))

# ---- 3. Uncertainty: moving-block bootstrap of the residuals, refitting the model ------
B <- 100; block <- 8
resid <- d$sales - fit$fitted; n <- nrow(d)
boot_one <- function(b) {
  starts <- sample(seq_len(n - block + 1), ceiling(n / block), replace = TRUE)
  e <- unlist(lapply(starts, function(s) resid[s:(s + block - 1)]))[seq_len(n)]
  db <- d; db$sales <- fit$fitted + e
  fb <- fit_mmm(db, start = fit$start)
  Zb <- channel_features(as.matrix(db[spend_cols]), fb$decay, fb$K)
  contrib <- colSums(sweep(Zb, 2, fb$beta, "*"))
  s_opt <- tryCatch(waterfill(fb$beta, fb$decay, fb$K, total, lo, hi), error = function(e) rep(NA_real_, length(CHANNELS)))
  tibble(rep = b, channel = CHANNELS, roi = contrib / colSums(d[spend_cols]), marginal_roi = marginal_roi(s0, fb$beta, fb$decay, fb$K),
         decay = unname(fb$decay), recommended_spend = s_opt)
}
boot <- bind_rows(lapply(seq_len(B), boot_one))
boot_summary <- boot |> group_by(channel) |>
  summarise(across(c(roi, marginal_roi, recommended_spend), list(lo = ~ quantile(.x, 0.025, na.rm = TRUE), hi = ~ quantile(.x, 0.975, na.rm = TRUE))), .groups = "drop")
print(boot_summary)

# How often does the bootstrap rank channels the same way as the point estimate (by marginal ROI)?
rank_check <- boot |> group_by(rep) |> mutate(rank = rank(-marginal_roi)) |> ungroup() |>
  count(channel, rank) |> group_by(channel) |> mutate(share = n / sum(n)) |> ungroup()
print(rank_check)

saveRDS(list(alloc = alloc, value = value, curves = curves, boot = boot, boot_summary = boot_summary, rank_check = rank_check,
             B = B, block = block, total = total),
        "data/clean/budget_results.rds")
