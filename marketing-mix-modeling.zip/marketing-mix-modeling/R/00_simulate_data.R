source("R/mmm_functions.R")
library(readr)

sim <- simulate_mmm(n_weeks = 156, seed = 2026, messy = TRUE)
write_csv(sim$raw, "data/raw/weekly_marketing.csv")
saveRDS(sim$truth, "data/clean/truth_contributions.rds")      # used only to grade the analysis
cat("Raw rows:", nrow(sim$raw), "\n")
